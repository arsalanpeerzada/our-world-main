#import <Flutter/Flutter.h>

@interface AgoraRtmPlugin : NSObject<FlutterPlugin>
@end
