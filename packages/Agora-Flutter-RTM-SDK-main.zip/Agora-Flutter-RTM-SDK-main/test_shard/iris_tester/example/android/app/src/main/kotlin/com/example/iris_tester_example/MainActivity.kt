package com.example.iris_tester_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
