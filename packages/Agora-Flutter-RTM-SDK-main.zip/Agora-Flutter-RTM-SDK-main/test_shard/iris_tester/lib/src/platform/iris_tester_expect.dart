import 'package:iris_tester/src/platform/iris_tester_interface.dart';

IrisTester createIrisTester() =>
    throw UnimplementedError('Unimplemented createIrisTester');
