#import "IrisTesterPlugin.h"

@implementation IrisTesterPlugin
+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar>*)registrar {
  // [SwiftIrisTesterPlugin registerWithRegistrar:registrar];
}
@end
