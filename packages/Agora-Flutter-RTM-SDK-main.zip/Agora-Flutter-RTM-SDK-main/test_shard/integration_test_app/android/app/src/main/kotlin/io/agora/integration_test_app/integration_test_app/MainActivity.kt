package io.agora.integration_test_app.integration_test_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
