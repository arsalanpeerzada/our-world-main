module.exports = [
  {
    source: "agora::rtc::IRtcEngineEventHandlerEx",
    target: "agora::rtc::IRtcEngineEventHandler",
    deleteSource: true,
  },
];
